import { Smartphone, Tablet, Monitor } from "lucide-react";

export interface DevicePreset {
  id: string;
  label: string;
  sublabel: string;
  widthPx: number;
  heightPx: number;
  icon: "phone" | "tablet" | "desktop";
}

export const DEVICE_PRESETS: DevicePreset[] = [
  {
    id: "small",
    label: "Small Phone",
    sublabel: "360 × 640",
    widthPx: 360,
    heightPx: 640,
    icon: "phone",
  },
  {
    id: "medium",
    label: "Medium Phone",
    sublabel: "390 × 844",
    widthPx: 390,
    heightPx: 844,
    icon: "phone",
  },
  {
    id: "large",
    label: "Large Phone",
    sublabel: "412 × 915",
    widthPx: 412,
    heightPx: 915,
    icon: "phone",
  },
  {
    id: "tablet",
    label: "Tablet",
    sublabel: "768 × 1024",
    widthPx: 768,
    heightPx: 1024,
    icon: "tablet",
  },
  {
    id: "full",
    label: "Full Width",
    sublabel: "No constraint",
    widthPx: 0,
    heightPx: 0,
    icon: "desktop",
  },
];

interface DeviceSelectorProps {
  selected: string;
  onChange: (id: string) => void;
}

export function DeviceSelector({ selected, onChange }: DeviceSelectorProps) {
  return (
    <div
      data-testid="device-selector"
      className="flex flex-wrap items-center gap-1.5 p-1 bg-muted/50 rounded-lg border border-border"
    >
      {DEVICE_PRESETS.map((preset) => {
        const Icon =
          preset.icon === "phone"
            ? Smartphone
            : preset.icon === "tablet"
            ? Tablet
            : Monitor;

        const isSelected = selected === preset.id;

        return (
          <button
            key={preset.id}
            data-testid={`device-${preset.id}`}
            onClick={() => onChange(preset.id)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all duration-150 ${
              isSelected
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-background hover:shadow-sm text-muted-foreground hover:text-foreground"
            }`}
          >
            <Icon className="w-3.5 h-3.5 shrink-0" />
            <span>{preset.label}</span>
            <span
              className={`font-mono ${
                isSelected ? "text-primary-foreground/70" : "opacity-50"
              }`}
            >
              {preset.sublabel}
            </span>
          </button>
        );
      })}
    </div>
  );
}

interface DeviceFrameProps {
  preset: DevicePreset;
  children: React.ReactNode;
}

const SCALE_MAX_WIDTH = 520;

export function DeviceFrame({ preset, children }: DeviceFrameProps) {
  if (preset.id === "full") {
    return (
      <div
        data-testid="device-frame-full"
        className="w-full bg-white dark:bg-zinc-900 rounded-lg border border-border overflow-auto"
        style={{ minHeight: 120 }}
      >
        {children}
      </div>
    );
  }

  const scale = Math.min(1, SCALE_MAX_WIDTH / preset.widthPx);
  const scaledW = preset.widthPx * scale;
  const scaledH = preset.heightPx * scale;

  const notchW = preset.icon === "tablet" ? 80 : 60;
  const bezelTop = preset.icon === "tablet" ? 20 : 18;
  const bezelSide = preset.icon === "tablet" ? 14 : 10;
  const bezelBottom = preset.icon === "tablet" ? 24 : 22;
  const cornerRadius = preset.icon === "tablet" ? 16 : 28;

  const outerW = scaledW + bezelSide * 2;
  const outerH = scaledH + bezelTop + bezelBottom;

  return (
    <div data-testid={`device-frame-${preset.id}`} className="flex flex-col items-center gap-3">
      <div
        className="relative flex-shrink-0"
        style={{ width: outerW, height: outerH }}
      >
        <div
          className="absolute inset-0 bg-zinc-800 dark:bg-zinc-700 shadow-2xl"
          style={{ borderRadius: cornerRadius }}
        />

        {preset.icon === "phone" && (
          <>
            <div
              className="absolute top-0 left-1/2 -translate-x-1/2 bg-zinc-900 dark:bg-zinc-600"
              style={{
                width: notchW,
                height: bezelTop,
                borderBottomLeftRadius: 10,
                borderBottomRightRadius: 10,
                top: 3,
              }}
            />
            <div
              className="absolute bg-zinc-700 dark:bg-zinc-500 rounded-full"
              style={{ width: 8, height: 8, left: -6, top: 80 }}
            />
            <div
              className="absolute bg-zinc-700 dark:bg-zinc-500 rounded-full"
              style={{ width: 8, height: 24, left: -6, top: 110 }}
            />
            <div
              className="absolute bg-zinc-700 dark:bg-zinc-500 rounded-full"
              style={{ width: 8, height: 24, left: -6, top: 144 }}
            />
            <div
              className="absolute bg-zinc-700 dark:bg-zinc-500 rounded-full"
              style={{ width: 8, height: 40, right: -6, top: 110 }}
            />
          </>
        )}

        {preset.icon === "tablet" && (
          <>
            <div
              className="absolute bg-zinc-600 dark:bg-zinc-500 rounded-full"
              style={{ width: 6, height: 6, left: "50%", transform: "translateX(-50%)", top: 7 }}
            />
            <div
              className="absolute bg-zinc-700 dark:bg-zinc-500 rounded-full"
              style={{ width: 6, height: 36, right: -5, top: "50%", transform: "translateY(-50%)" }}
            />
          </>
        )}

        <div
          className="absolute bg-zinc-900 overflow-hidden"
          style={{
            top: bezelTop,
            left: bezelSide,
            width: scaledW,
            height: scaledH,
            borderRadius: 4,
          }}
        >
          <div
            className="bg-white dark:bg-zinc-900 w-full h-full overflow-auto"
            style={{
              transformOrigin: "top left",
            }}
          >
            <div style={{ width: preset.widthPx, transform: `scale(${scale})`, transformOrigin: "top left" }}>
              {children}
            </div>
          </div>
        </div>

        <div
          className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-zinc-600 dark:bg-zinc-500 rounded-full"
          style={{ width: preset.icon === "tablet" ? 32 : 28, height: 4 }}
        />
      </div>

      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span className="font-medium">{preset.label}</span>
        <span className="font-mono opacity-60">{preset.widthPx} × {preset.heightPx} dp</span>
        {scale < 1 && (
          <span className="opacity-50">({Math.round(scale * 100)}% scale)</span>
        )}
      </div>
    </div>
  );
}
