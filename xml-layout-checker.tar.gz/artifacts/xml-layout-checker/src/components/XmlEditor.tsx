import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { X, Upload, Eye, EyeOff, FileCode } from "lucide-react";
import type { XmlFile } from "@/lib/xml-utils";

interface XmlEditorProps {
  file: XmlFile;
  index: number;
  onContentChange: (id: string, content: string) => void;
  onToggle: (id: string) => void;
  onRemove: (id: string) => void;
}

export function XmlEditor({ file, index, onContentChange, onToggle, onRemove }: XmlEditorProps) {
  return (
    <div
      data-testid={`xml-editor-${file.id}`}
      className={`border rounded-lg overflow-hidden transition-all duration-200 ${
        file.enabled
          ? "border-border bg-card shadow-sm"
          : "border-border/50 bg-muted/30 opacity-60"
      }`}
    >
      <div className="flex items-center gap-2 px-3 py-2 bg-muted/40 border-b border-border">
        <FileCode className="w-4 h-4 text-primary shrink-0" />
        <span className="text-sm font-medium text-foreground truncate flex-1">{file.name}</span>
        <Badge variant="secondary" className="text-xs shrink-0">
          File {index + 1}
        </Badge>
        <button
          data-testid={`toggle-file-${file.id}`}
          onClick={() => onToggle(file.id)}
          className="p-1 rounded hover:bg-accent transition-colors"
          title={file.enabled ? "Hide from preview" : "Show in preview"}
        >
          {file.enabled ? (
            <Eye className="w-3.5 h-3.5 text-primary" />
          ) : (
            <EyeOff className="w-3.5 h-3.5 text-muted-foreground" />
          )}
        </button>
        <button
          data-testid={`remove-file-${file.id}`}
          onClick={() => onRemove(file.id)}
          className="p-1 rounded hover:bg-destructive/10 hover:text-destructive transition-colors"
          title="Remove file"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
      <Textarea
        data-testid={`textarea-${file.id}`}
        value={file.content}
        onChange={(e) => onContentChange(file.id, e.target.value)}
        placeholder={`<!-- XML content for ${file.name} -->\n<LinearLayout\n  android:orientation="vertical"\n  android:layout_width="match_parent"\n  android:layout_height="wrap_content">\n\n  <TextView\n    android:text="Hello World"\n    android:layout_width="wrap_content"\n    android:layout_height="wrap_content" />\n\n</LinearLayout>`}
        className="min-h-[200px] font-mono text-xs border-0 rounded-none focus-visible:ring-0 resize-y bg-transparent"
      />
    </div>
  );
}
