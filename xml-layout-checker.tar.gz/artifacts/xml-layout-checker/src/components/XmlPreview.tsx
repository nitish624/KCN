import { useMemo } from "react";
import { AlertCircle, CheckCircle2, FileX } from "lucide-react";
import { parseXml, renderPreviewNode } from "@/lib/xml-utils";
import type { XmlFile } from "@/lib/xml-utils";
import { DeviceFrame } from "@/components/DeviceFrame";
import type { DevicePreset } from "@/components/DeviceFrame";

interface XmlPreviewProps {
  files: XmlFile[];
  devicePreset: DevicePreset;
}

export function XmlPreview({ files, devicePreset }: XmlPreviewProps) {
  const activeFiles = files.filter((f) => f.enabled && f.content.trim());

  const results = useMemo(() => {
    return activeFiles.map((f) => {
      const result = parseXml(f.content);
      let html = "";
      if (result.success && result.root) {
        try {
          html = renderPreviewNode(result.root);
        } catch (e) {
          html = "";
        }
      }
      return { file: f, result, html };
    });
  }, [activeFiles]);

  if (activeFiles.length === 0) {
    return (
      <div
        data-testid="preview-empty"
        className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-3"
      >
        <FileX className="w-12 h-12 opacity-30" />
        <p className="text-sm">Koi active XML file nahi hai</p>
        <p className="text-xs opacity-60">Upar se file add karo ya XML likhna shuru karo</p>
      </div>
    );
  }

  return (
    <div data-testid="preview-container" className="space-y-10">
      {results.map(({ file, result, html }) => (
        <div
          key={file.id}
          data-testid={`preview-file-${file.id}`}
          className="space-y-3"
        >
          <div className="flex items-center gap-2 px-1">
            {result.success ? (
              <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-destructive shrink-0" />
            )}
            <span className="text-sm font-medium">{file.name}</span>
            {result.success ? (
              <span className="text-xs text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded-full">
                Valid XML
              </span>
            ) : (
              <span className="text-xs text-destructive bg-destructive/10 px-2 py-0.5 rounded-full">
                Error
              </span>
            )}
          </div>

          {result.success && html ? (
            <div className="flex justify-center">
              <DeviceFrame preset={devicePreset}>
                <div
                  data-testid={`preview-render-${file.id}`}
                  className="p-3"
                  dangerouslySetInnerHTML={{ __html: html }}
                />
              </DeviceFrame>
            </div>
          ) : (
            <div className="p-4 bg-destructive/5 rounded-lg border border-destructive/20">
              <p className="text-xs font-mono text-destructive leading-relaxed">
                {result.error}
              </p>
            </div>
          )}
        </div>
      ))}

      {results.length > 1 && results.every((r) => r.result.success) && (
        <div
          data-testid="preview-combined"
          className="space-y-3"
        >
          <div className="flex items-center gap-2 px-1">
            <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
            <span className="text-sm font-semibold text-primary">
              Combined Preview — {results.length} files ka combined effect
            </span>
            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
              Ek screen par sab
            </span>
          </div>
          <div className="flex justify-center">
            <DeviceFrame preset={devicePreset}>
              <div
                data-testid="preview-combined-render"
                className="p-3 space-y-3"
              >
                {results.map(({ file, html }) => (
                  <div key={file.id} dangerouslySetInnerHTML={{ __html: html }} />
                ))}
              </div>
            </DeviceFrame>
          </div>
        </div>
      )}
    </div>
  );
}
