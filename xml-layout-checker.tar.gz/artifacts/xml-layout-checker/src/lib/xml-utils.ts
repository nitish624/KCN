export interface XmlFile {
  id: string;
  name: string;
  content: string;
  enabled: boolean;
}

export interface ParsedNode {
  tag: string;
  attrs: Record<string, string>;
  children: ParsedNode[];
  text?: string;
}

export interface ParseResult {
  success: boolean;
  root?: ParsedNode;
  error?: string;
}

export function parseXml(content: string): ParseResult {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(content, "application/xml");
    const parserError = doc.querySelector("parsererror");
    if (parserError) {
      return { success: false, error: parserError.textContent || "XML parse error" };
    }
    const root = domToNode(doc.documentElement);
    return { success: true, root };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

function domToNode(el: Element): ParsedNode {
  const attrs: Record<string, string> = {};
  for (let i = 0; i < el.attributes.length; i++) {
    const a = el.attributes[i];
    attrs[a.name] = a.value;
  }

  const children: ParsedNode[] = [];
  let text = "";

  el.childNodes.forEach((child) => {
    if (child.nodeType === Node.ELEMENT_NODE) {
      children.push(domToNode(child as Element));
    } else if (child.nodeType === Node.TEXT_NODE) {
      const t = child.textContent?.trim() || "";
      if (t) text += t;
    }
  });

  return { tag: el.tagName, attrs, children, text: text || undefined };
}

export function mergeXmlFiles(files: XmlFile[]): ParseResult[] {
  return files
    .filter((f) => f.enabled && f.content.trim())
    .map((f) => ({ ...parseXml(f.content), fileName: f.name })) as ParseResult[];
}

export function xmlToHtmlPreview(node: ParsedNode, depth = 0): string {
  const indent = "  ".repeat(depth);
  const attrStr = Object.entries(node.attrs)
    .map(([k, v]) => `${k}="${v}"`)
    .join(" ");

  const openTag = `${node.tag}${attrStr ? " " + attrStr : ""}`;

  if (node.children.length === 0 && !node.text) {
    return `${indent}&lt;${openTag} /&gt;`;
  }

  const childrenHtml = node.children
    .map((c) => xmlToHtmlPreview(c, depth + 1))
    .join("\n");

  const textContent = node.text ? `${indent}  ${node.text}` : "";
  const inner = [textContent, childrenHtml].filter(Boolean).join("\n");

  return `${indent}&lt;${openTag}&gt;\n${inner}\n${indent}&lt;/${node.tag}&gt;`;
}

export function renderPreviewNode(node: ParsedNode): string {
  return buildHtmlFromXml(node);
}

function buildHtmlFromXml(node: ParsedNode): string {
  const tag = node.tag.toLowerCase();

  const safeHtmlTags = new Set([
    "div", "span", "p", "h1", "h2", "h3", "h4", "h5", "h6",
    "ul", "ol", "li", "table", "thead", "tbody", "tr", "th", "td",
    "form", "label", "input", "button", "textarea", "select", "option",
    "img", "a", "section", "article", "main", "header", "footer", "nav",
    "aside", "figure", "figcaption", "strong", "em", "code", "pre",
    "blockquote", "hr", "br"
  ]);

  const styleMap: Record<string, string> = {
    linearlayout: "display:flex;flex-direction:column;gap:8px;",
    relativelayout: "position:relative;",
    framelayout: "position:relative;",
    constraintlayout: "display:flex;flex-direction:column;gap:8px;",
    scrollview: "overflow:auto;max-height:400px;",
    recyclerview: "overflow:auto;",
    gridlayout: "display:grid;gap:8px;",
    textview: "display:block;",
    edittext: "display:block;border:1px solid #ccc;padding:4px;border-radius:4px;",
    button: "display:inline-block;padding:8px 16px;background:#3b82f6;color:white;border-radius:4px;cursor:pointer;border:none;",
    imageview: "display:block;",
    cardview: "display:block;border:1px solid #e2e8f0;border-radius:8px;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.1);",
    toolbar: "display:flex;align-items:center;background:#1e40af;color:white;padding:8px 16px;",
    appbarlayout: "display:block;",
    coordinatorlayout: "display:flex;flex-direction:column;",
    nestedscrollview: "overflow:auto;max-height:400px;",
    tablelayout: "display:table;width:100%;",
    tablerow: "display:table-row;",
    checkbox: "display:flex;align-items:center;gap:4px;",
    radiobutton: "display:flex;align-items:center;gap:4px;",
    radiogroup: "display:flex;flex-direction:column;gap:4px;",
    switch: "display:flex;align-items:center;gap:4px;",
    progressbar: "display:block;height:8px;background:#e2e8f0;border-radius:4px;overflow:hidden;",
    view: "display:block;",
    viewgroup: "display:block;",
  };

  const getStyle = (n: ParsedNode): string => {
    const tagLower = n.tag.toLowerCase().replace(/^[a-z]+\./, "");
    let style = styleMap[tagLower] || "display:block;";

    const android: Record<string, string> = {};
    Object.entries(n.attrs).forEach(([k, v]) => {
      const key = k.replace(/^android:/, "").replace(/^app:/, "");
      android[key] = v;
    });

    if (android["orientation"] === "horizontal") {
      style = style.replace("flex-direction:column;", "flex-direction:row;");
    }
    if (android["layout_width"] === "match_parent" || android["layout_width"] === "fill_parent") {
      style += "width:100%;";
    }
    if (android["layout_height"] === "match_parent" || android["layout_height"] === "fill_parent") {
      style += "height:100%;";
    }
    if (android["background"]) {
      const bg = android["background"];
      if (bg.startsWith("#")) style += `background:${bg};`;
    }
    if (android["padding"]) style += `padding:${android["padding"].replace("dp", "px").replace("sp", "px")};`;
    if (android["layout_margin"]) style += `margin:${android["layout_margin"].replace("dp", "px").replace("sp", "px")};`;
    if (android["textSize"]) style += `font-size:${android["textSize"].replace("sp", "px")};`;
    if (android["textColor"] && android["textColor"].startsWith("#")) {
      style += `color:${android["textColor"]};`;
    }
    if (android["visibility"] === "gone") style += "display:none;";
    if (android["visibility"] === "invisible") style += "visibility:hidden;";

    return style;
  };

  const getText = (n: ParsedNode): string => {
    const android: Record<string, string> = {};
    Object.entries(n.attrs).forEach(([k, v]) => {
      const key = k.replace(/^android:/, "").replace(/^app:/, "");
      android[key] = v;
    });
    return android["text"] || android["hint"] || n.text || "";
  };

  const getHint = (n: ParsedNode): string => {
    const android: Record<string, string> = {};
    Object.entries(n.attrs).forEach(([k, v]) => {
      const key = k.replace(/^android:/, "").replace(/^app:/, "");
      android[key] = v;
    });
    return android["hint"] || "";
  };

  const tagLower = tag.toLowerCase().replace(/^[a-z]+\./i, "").toLowerCase();
  const style = getStyle(node);
  const text = getText(node);
  const childrenHtml = node.children.map(buildHtmlFromXml).join("");

  if (tagLower === "textview") {
    return `<span style="${style}">${text || childrenHtml || "&nbsp;"}</span>`;
  }
  if (tagLower === "edittext") {
    return `<input type="text" placeholder="${getHint(node) || text}" style="${style}" />`;
  }
  if (tagLower === "button") {
    return `<button style="${style}">${text || "Button"}</button>`;
  }
  if (tagLower === "imageview") {
    const src = node.attrs["android:src"] || node.attrs["app:srcCompat"] || "";
    return `<div style="${style}background:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:80px;border-radius:4px;">${src ? `<img src="${src}" style="max-width:100%;max-height:100%;" alt="image" />` : '<span style="color:#94a3b8;font-size:12px;">Image</span>'}</div>`;
  }
  if (tagLower === "checkbox") {
    return `<label style="${style}"><input type="checkbox" /> ${text}</label>`;
  }
  if (tagLower === "radiobutton") {
    return `<label style="${style}"><input type="radio" /> ${text}</label>`;
  }
  if (tagLower === "switch") {
    return `<label style="${style}"><input type="checkbox" role="switch" /> ${text}</label>`;
  }
  if (tagLower === "progressbar") {
    const progress = node.attrs["android:progress"] || "50";
    return `<div style="${style}"><div style="height:100%;width:${progress}%;background:#3b82f6;border-radius:4px;"></div></div>`;
  }

  if (safeHtmlTags.has(tagLower) && tagLower !== "input") {
    return `<${tagLower} style="${style}">${text}${childrenHtml}</${tagLower}>`;
  }

  return `<div style="${style}">${text}${childrenHtml}</div>`;
}
