import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { XmlEditor } from "@/components/XmlEditor";
import { XmlPreview } from "@/components/XmlPreview";
import { DeviceSelector, DEVICE_PRESETS } from "@/components/DeviceFrame";
import type { DevicePreset } from "@/components/DeviceFrame";
import { Upload, Plus, Eye, Code2, Moon, Sun, Layers } from "lucide-react";
import type { XmlFile } from "@/lib/xml-utils";

let counter = 0;
function newId() {
  return `xml-${++counter}-${Date.now()}`;
}

function createEmptyFile(name = "layout.xml"): XmlFile {
  return { id: newId(), name, content: "", enabled: true };
}

export default function Home() {
  const [files, setFiles] = useState<XmlFile[]>([createEmptyFile("layout1.xml")]);
  const [showPreview, setShowPreview] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("medium");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedDevice: DevicePreset =
    DEVICE_PRESETS.find((d) => d.id === selectedDeviceId) ?? DEVICE_PRESETS[1];

  const toggleDark = () => {
    setDarkMode((d) => {
      document.documentElement.classList.toggle("dark", !d);
      return !d;
    });
  };

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(e.target.files || []);
    if (!uploadedFiles.length) return;
    uploadedFiles.forEach((f) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const content = (ev.target?.result as string) || "";
        setFiles((prev) => [
          ...prev,
          { id: newId(), name: f.name, content, enabled: true },
        ]);
      };
      reader.readAsText(f);
    });
    if (fileInputRef.current) fileInputRef.current.value = "";
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const droppedFiles = Array.from(e.dataTransfer.files).filter((f) =>
      f.name.endsWith(".xml")
    );
    droppedFiles.forEach((f) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const content = (ev.target?.result as string) || "";
        setFiles((prev) => [
          ...prev,
          { id: newId(), name: f.name, content, enabled: true },
        ]);
      };
      reader.readAsText(f);
    });
  }, []);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const addNewFile = () => {
    setFiles((prev) => [
      ...prev,
      createEmptyFile(`layout${prev.length + 1}.xml`),
    ]);
  };

  const updateContent = (id: string, content: string) => {
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, content } : f)));
  };

  const toggleFile = (id: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, enabled: !f.enabled } : f))
    );
  };

  const removeFile = (id: string) => {
    setFiles((prev) => {
      const updated = prev.filter((f) => f.id !== id);
      return updated.length === 0 ? [createEmptyFile("layout.xml")] : updated;
    });
  };

  const activeCount = files.filter((f) => f.enabled && f.content.trim()).length;

  return (
    <div
      className="min-h-screen bg-background text-foreground flex flex-col"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <header className="border-b border-border bg-card/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="flex items-center gap-2.5 flex-1">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
              <Layers className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-none">XML Layout Checker</h1>
              <p className="text-xs text-muted-foreground">Android / Web XML layout preview tool</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              data-testid="toggle-dark"
              onClick={toggleDark}
              className="p-2 rounded-md hover:bg-muted transition-colors"
              title="Toggle dark mode"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <Button
              data-testid="upload-btn"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload XML
            </Button>

            <Button
              data-testid="add-file-btn"
              variant="outline"
              size="sm"
              onClick={addNewFile}
              className="gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              New File
            </Button>

            <Button
              data-testid="preview-btn"
              size="sm"
              onClick={() => setShowPreview((p) => !p)}
              className="gap-1.5"
            >
              {showPreview ? (
                <>
                  <Code2 className="w-3.5 h-3.5" />
                  Editor
                </>
              ) : (
                <>
                  <Eye className="w-3.5 h-3.5" />
                  Preview {activeCount > 0 && `(${activeCount})`}
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      <input
        ref={fileInputRef}
        type="file"
        accept=".xml"
        multiple
        className="hidden"
        onChange={handleFileUpload}
        data-testid="file-input"
      />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
        {!showPreview ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Code2 className="w-4 h-4" />
              <span>
                {files.length} file{files.length !== 1 ? "s" : ""} —{" "}
                <span className="text-foreground font-medium">{activeCount} active</span>
              </span>
              <span className="ml-auto text-xs opacity-60">
                XML files ko drag &amp; drop bhi kar sakte ho
              </span>
            </div>

            <div className="grid gap-4">
              {files.map((file, idx) => (
                <XmlEditor
                  key={file.id}
                  file={file}
                  index={idx}
                  onContentChange={updateContent}
                  onToggle={toggleFile}
                  onRemove={removeFile}
                />
              ))}
            </div>

            <div
              className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
              onClick={addNewFile}
              data-testid="add-file-drop-zone"
            >
              <Plus className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                New file add karo ya XML file yahan drop karo
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Eye className="w-4 h-4" />
                <span>
                  Rendered preview —{" "}
                  <span className="text-foreground font-medium">
                    {activeCount} active file{activeCount !== 1 ? "s" : ""}
                  </span>
                </span>
                {activeCount > 1 && (
                  <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                    Combined effect bhi dikhega
                  </span>
                )}
              </div>

              <DeviceSelector
                selected={selectedDeviceId}
                onChange={setSelectedDeviceId}
              />
            </div>

            <XmlPreview files={files} devicePreset={selectedDevice} />
          </div>
        )}
      </main>

      <footer className="border-t border-border py-3 text-center text-xs text-muted-foreground">
        XML Layout Checker — Android &amp; Web XML layouts ka preview
      </footer>
    </div>
  );
}
